# Client-Server App Artifacts

В этом репозитории собраны артефакты проекта:

- **Dockerfile.server** – серверное приложение (Python/FastAPI или Flask)
- **Dockerfile.client** – клиентское приложение (Node.js/React)
- **use_case.puml** – Use Case диаграмма (PlantUML)
- **class_server.puml** – диаграмма классов сервера
- **class_client.puml** – диаграмма классов клиента
- **test_case.md** – пример тест-кейса
- **defect.md** – пример отчета о дефекте
- **Doxyfile** – конфигурация для Doxygen

## 📦 Запуск Docker
```bash
# Сервер
docker build -f Dockerfile.server -t server-app .
docker run -p 8000:8000 server-app

# Клиент
docker build -f Dockerfile.client -t client-app .
docker run -p 3000:3000 client-app
```

## 📊 Диаграммы
Открыть `.puml` файлы можно в:
- [PlantUML Editor](https://plantuml.com/ru/online)
- VSCode + расширение PlantUML
- IntelliJ IDEA / PyCharm с плагином PlantUML
